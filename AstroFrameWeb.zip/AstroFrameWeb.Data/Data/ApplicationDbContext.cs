﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using AstroFrameWeb.Data;
using AstroFrameWeb.Data.Models;

namespace AstroFrameWeb.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Galaxy> Galaxies { get; set; } = null!;
        public DbSet<Star> Stars { get; set; } = null!;
        public DbSet<Planet> Planets { get; set; } = null!;
        public DbSet<StarComment> StarComments { get; set; } = null!;
        public DbSet<PlanetComment> PlanetComments { get; set; } = null!;
    }
}
